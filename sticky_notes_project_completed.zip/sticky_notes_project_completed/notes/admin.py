from django.contrib import admin
from .models import Note

# Docstring for the class (module-level documentation is often put at the top of the file,
# but for a small admin configuration, a class docstring suffices)

@admin.register(Note)
class NoteAdmin(admin.ModelAdmin):
    """
    Admin configuration for the Note model.

    Customizes the appearance and behavior of the Note model in the Django
    admin interface.
    """

    # Specifies which fields to display in the change list view of the admin
    list_display = ('id', 'title', 'created_at')

    # Specifies which fields to use for searching in the admin change list view
    search_fields = ('title', 'content')
