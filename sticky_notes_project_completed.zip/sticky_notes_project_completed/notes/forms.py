from django import forms
from .models import Note


class NoteForm(forms.ModelForm):
    """
    A ModelForm for creating and updating Note instances.

    This form automatically generates form fields based on the Note model
    and applies custom widgets and CSS classes for styling.
    """
    class Meta:
        """
        Configuration options for the NoteForm.
        """
        model = Note
        # Specifies the fields from the model that should be included in the 
        # form
        fields = ['title', 'content']
        # Specifies custom HTML widgets and attributes for form fields
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control'}),
            'content': forms.Textarea(attrs={'class': 'form-control', 'rows': 6}),
        }
