from django.db import models
from django.urls import reverse


class Note(models.Model):
    """
    Represents a sticky note entry in the database.

    Stores the note's title, main content, and the timestamp of its creation.
    """
    # Character field for the note's title, limited to 255 characters.
    title = models.CharField(max_length=255)

    # Text field for the main content of the note (allows for a large amount
    # of text).
    content = models.TextField()

    # Date and time field that is automatically set when the object is first
    # created.
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        """
        Returns a string representation of the Note instance.
        This is used, for example, in the Django admin interface.
        """
        return self.title

    def get_absolute_url(self):
        """
        Returns the canonical URL for a specific Note instance.

        It uses Django's reverse function to dynamically generate the URL 
        based on the 'note_detail' URL pattern and the note's primary key (id).
        """
        return reverse('note_detail', args=[str(self.id)])
