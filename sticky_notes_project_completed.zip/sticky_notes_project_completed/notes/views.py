from django.shortcuts import render, get_object_or_404, redirect
from .models import Note
from .forms import NoteForm


def note_list(request):
    """
    Displays a list of all notes, ordered by creation date (newest first).

    Retrieves all Note objects from the database, sorts them, and renders them
    using the 'notes/note_list.html' template.

    :param request: The incoming HTTP request object.
    :return: An HTTP response rendering the note list template.
    :rtype: django.http.HttpResponse
    """
    notes = Note.objects.order_by('-created_at')
    return render(request, 'notes/note_list.html', {'notes': notes})


def note_detail(request, pk):
    """
    Displays the details of a single note.

    Retrieves a single Note object by its primary key (pk). If the note
    does not exist, it raises an Http404 error. Renders the result using
    the 'notes/note_detail.html' template.

    :param request: The incoming HTTP request object.
    :param pk: The primary key (ID) of the Note to retrieve.
    :type pk: int
    :return: An HTTP response rendering the note detail template.
    :rtype: django.http.HttpResponse
    """
    note = get_object_or_404(Note, pk=pk)
    return render(request, 'notes/note_detail.html', {'note': note})


def note_create(request):
    """
    Handles the creation of a new note using a form.

    On a POST request, it validates the submitted data. If valid, it saves
    the new note and redirects to the note list.
    On a GET request, it displays a blank form.

    :param request: The incoming HTTP request object.
    :return: An HTTP response rendering the note form or a redirect.
    :rtype: django.http.HttpResponse or django.http.HttpResponseRedirect
    """
    if request.method == 'POST':
        form = NoteForm(request.POST)
        if form.is_valid():
            form.save()
            # Redirect to the note list view
            return redirect('note_list')
    else:
        # Display a blank form for GET request
        form = NoteForm()
    return render(request, 'notes/note_form.html', {'form': form, 'is_create': True})


def note_update(request, pk):
    """
    Handles the updating of an existing note.

    Retrieves the Note instance by its primary key (pk).
    On a POST request, it validates the submitted data against the instance.
    If valid, it updates the note and redirects to the note detail view.
    On a GET request, it displays the form pre-filled with the note's data.

    :param request: The incoming HTTP request object.
    :param pk: The primary key (ID) of the Note to update.
    :type pk: int
    :return: An HTTP response rendering the note form or a redirect.
    :rtype: django.http.HttpResponse or django.http.HttpResponseRedirect
    """
    note = get_object_or_404(Note, pk=pk)
    if request.method == 'POST':
        # Pass the existing instance to the form for updating
        form = NoteForm(request.POST, instance=note)
        if form.is_valid():
            form.save()
            # Redirect to the detail page of the updated note
            return redirect('note_detail', pk=note.pk)
    else:
        # Pre-fill the form with the existing instance data
        form = NoteForm(instance=note)
    return render(request, 'notes/note_form.html', {'form': form, 'is_create': False})


def note_delete(request, pk):
    """
    Handles the deletion of an existing note.

    Retrieves the Note instance by its primary key (pk).
    On a POST request (typically submitted from a confirmation page), it
    deletes
    the note and redirects to the note list view.
    On a GET request, it displays a confirmation template.

    :param request: The incoming HTTP request object.
    :param pk: The primary key (ID) of the Note to delete.
    :type pk: int
    :return: An HTTP response rendering the confirmation template or a
     redirect.
    :rtype: django.http.HttpResponse or django.http.HttpResponseRedirect
    """
    note = get_object_or_404(Note, pk=pk)
    if request.method == 'POST':
        note.delete()
        # Redirect to the note list after deletion
        return redirect('note_list')
    # Display confirmation page on GET
    return render(request, 'notes/note_confirm_delete.html', {'note': note})
