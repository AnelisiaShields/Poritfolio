ffrom django.test import TestCase
from django.urls import reverse
from .models import Note
from .forms import NoteForm

class NoteModelTest(TestCase):
    """
    Unit tests for the Note model functionality.

    Verifies methods and behavior intrinsic to the Note model itself, 
    independent of views or forms.
    """
    def setUp(self):
        """
        Create a single Note instance used as the test subject for model tests.
        """
        self.note = Note.objects.create(title='Test Note', content='This is a test note.')

    def test_str_returns_title(self):
        """
        Verifies that the __str__ method returns the note's title.
        """
        self.assertEqual(str(self.note), 'Test Note')

    def test_get_absolute_url(self):
        """
        Verifies that get_absolute_url returns the correct detail URL.
        
        The generated URL should match the result of reversing 'note_detail' 
        with the note's primary key (ID).
        """
        expected = reverse('note_detail', args=[str(self.note.id)])
        self.assertEqual(self.note.get_absolute_url(), expected)


class NoteViewTests(TestCase):
    """
    Integration tests for the Note application's views (list, detail, CRUD).

    Uses the Django test client to simulate HTTP requests and check the 
    status codes and content of the responses.
    """
    def setUp(self):
        """
        Create a single Note instance to test view retrieval and modification.
        This instance is created in the database before each test method runs.
        """
        self.note = Note.objects.create(title='View Note', content='Content for view note.')

    def test_note_list_view(self):
        """
        Tests the note list view (GET request).

        Verifies status code is **200 (OK)** and the page content contains 
        the title of the existing note, ensuring data is displayed correctly.
        """
        response = self.client.get(reverse('note_list'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, self.note.title)

    def test_note_detail_view(self):
        """
        Tests the single note detail view (GET request).

        Verifies status code is **200 (OK)** and the page contains both 
        the title and content of the specific note, confirming correct object retrieval.
        """
        response = self.client.get(reverse('note_detail', args=[str(self.note.id)]))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, self.note.title)
        self.assertContains(response, self.note.content)

    def test_note_create_view(self):
        """
        Tests the note creation view (**POST** request).

        Simulates posting valid form data. Verifies a successful redirect 
        (status code **302/301**) and asserts that the new note record 
        now exists in the database.
        """
        data = {'title': 'Created Note', 'content': 'Created content.'}
        response = self.client.post(reverse('note_create'), data)
        # Expect a redirect after successful creation
        self.assertIn(response.status_code, (302, 301))
        self.assertTrue(Note.objects.filter(title='Created Note').exists())

    def test_note_update_view(self):
        """
        Tests the note update view (**POST** request).

        Simulates posting updated data to the edit URL. Verifies a redirect 
        and confirms the changes are correctly **persisted in the database** by reloading the object (`refresh_from_db`).
        """
        url = reverse('note_update', args=[str(self.note.id)])
        data = {'title': 'Updated Title', 'content': 'Updated content.'}
        response = self.client.post(url, data)
        self.assertIn(response.status_code, (302, 301))
        
        # Reload the object from the database to check updated values
        self.note.refresh_from_db()
        self.assertEqual(self.note.title, 'Updated Title')
        self.assertEqual(self.note.content, 'Updated content.')

    def test_note_delete_view(self):
        """
        Tests the note deletion view (**POST** request).

        Simulates posting to the delete endpoint. Verifies a redirect 
        and confirms the note **no longer exists** in the database.
        """
        url = reverse('note_delete', args=[str(self.note.id)])
        response = self.client.post(url)
        self.assertIn(response.status_code, (302, 301))
        self.assertFalse(Note.objects.filter(id=self.note.id).exists())


class NoteFormTest(TestCase):
    """
    Unit tests for the NoteForm validation and field behavior, isolated from the views.
    """
    def test_valid_form(self):
        """
        Tests that the form is valid when all required data (title and content) is provided.
        """
        data = {'title': 'Form Title', 'content': 'Some content.'}
        form = NoteForm(data=data)
        self.assertTrue(form.is_valid())

    def test_invalid_form(self):
        """
        Tests that the form is invalid when required fields (title and content) are empty.
        """
        data = {'title': '', 'content': ''}
        form = NoteForm(data=data)
        self.assertFalse(form.is_valid())