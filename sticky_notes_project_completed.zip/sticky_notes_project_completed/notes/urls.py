from django.urls import path
from . import views

"""
Defines the URL patterns for the 'notes' application.

Each path maps a URL route to a specific view function 
in the 'views.py' file and assigns a unique name for referencing 
the URL programmatically (e.g., using reverse()).
"""

# List of URL patterns (routes) for the 'notes' application.
urlpatterns = [
    # Route for the list view (homepage for notes)
    path('', views.note_list, name='note_list'),

    # Route for creating a new note
    path('note/new/', views.note_create, name='note_create'),

    # Route for viewing a single note (detail view)
    # The <int:pk> captures the primary key (ID) as an integer
    path('note/<int:pk>/', views.note_detail, name='note_detail'),

    # Route for editing an existing note
    path('note/<int:pk>/edit/', views.note_update, name='note_update'),

    # Route for deleting a specific note
    path('note/<int:pk>/delete/', views.note_delete, name='note_delete'),
]
